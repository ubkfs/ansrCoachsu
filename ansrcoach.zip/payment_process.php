<?php
session_start();
include('../public_html/in/_db_connect.php');
if(isset($_POST['amt']) && isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone'])){
    $amt=$_POST['amt'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $payment_status="pending";
    $sql="INSERT INTO `payment` (`id`, `name`, `email`, `phone`, `amount`, `payment_id`,`payment_status`, `date`) VALUES (NULL, '$name', '$email', '$phone', '$amt', '$payment_status','$payment_id', current_timestamp());";
    mysqli_query($conn,$sql);
    $_SESSION['OID']=mysqli_insert_id($conn);
}


if(isset($_POST['payment_id']) && isset($_SESSION['OID'])){
    $payment_id=$_POST['payment_id'];
    mysqli_query($conn,"update payment set payment_status='complete',payment_id='$payment_id' where id='".$_SESSION['OID']."'");
}
?>