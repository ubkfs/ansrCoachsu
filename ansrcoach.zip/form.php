
<?php require "../public_html/in/nav.php" ?>



<br><br><br><br><br><br><br>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

<style>
  body{
        background: linear-gradient(rgb(15, 138, 175),rgb(81, 124, 81),rgb(115, 165, 36)) fixed;
    }
.card{
    width:360px;
    background: rgb(14, 13, 13);
    display:block;
    margin:auto;
    border-top-left-radius:14px;
    border-bottom-right-radius:14px;
    box-shadow: rgba(114, 61, 61, 0.4) 5px 5px,
    rgba(184, 42, 42, 0.3) 10px 10px, 
    rgba(221, 24, 24, 0.2) 15px 15px,
     rgba(236, 11, 11, 0.1) 20px 20px, 
     rgba(253, 2, 2, 0.05) 25px 25px;
     margin-bottom:50px;
}
.card-title{
    color:white;
}
.form-group{
    color:white;
}
</style>

<div class="card text-center">

<div class="card-body">
  <h2 class="card-title">Give details and have invoice</h2>
  <form action="/pdf.php" method="POST">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name">
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" class="form-control my-2" id="phone" name="phone">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" class="form-control my-2" id="email" name="email">
        </div>
        <div class="form-group">
            <label for="amt">Enter Amount</label>
            <input type="text" class="form-control my-2" id="amt" name="amt" placeholder="Enetr amount">
        </div>
        <input type="submit" class="btn btn-outline-success" name="submit" value="Generate invoice">
     </form>
</div>

</div>

