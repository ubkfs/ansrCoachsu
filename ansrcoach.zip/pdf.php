<?php
  require("../public_html/fpdf/fpdf.php");
  $pdf=new FPDF();

if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $amt=$_POST['amt'];
  
    $pdf->AddPage();
    $pdf->SetFont("Arial","",16);
    $pdf->Cell(0,10,"AnsrCoach Society Upliftment",1,2,'C');
    $pdf->Cell(65,10,"Name",1,0);
    $pdf->Cell(65,10,"Email",1,0);
    $pdf->Cell(45,10,"Phone",1,0);
    $pdf->Cell(0,10,"amt",1,1);

    $pdf->Cell(65,10,"$name",1,0);
    $pdf->Cell(65,10,"$email",1,0);
    $pdf->Cell(45,10,"$phone",1,0);
    $pdf->Cell(0,10,"$amt",1,1);
    $pdf->Output();

}
?>