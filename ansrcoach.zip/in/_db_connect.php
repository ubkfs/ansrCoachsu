<?php
$servername="localhost";
$username="id18148497_ansrcoachsu";
$password="\w9BZbt^oOEHx?Zb";
$database= "id18148497_ansrcoach";

$conn=mysqli_connect($servername,$username,$password,$database);
if(!$conn){
    die("Error due to" . mysqli_connect_error());
}



?>