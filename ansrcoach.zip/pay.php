<?php 
require '../public_html/in/nav.php';?>
<br><br>
<style>
    body{
        background: linear-gradient(rgb(15, 138, 175),rgb(81, 124, 81),rgb(115, 165, 36)) fixed;
    }
    h1{
        text-align:center;
        
    }
    .btn{
        text-align:center;
        justify-content:center;
        display:block;
        margin:auto;        }
    }
    </style>
<h1><strong>Thank You For Helping!!</strong></h1>
<a href="/form.php" class="btn btn-outline-primary" method="POST" type="submit" name="submit">Generate invoice</a>
