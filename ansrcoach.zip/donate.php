
<?php require "../public_html/in/nav.php" ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<br><br><br><br><br><br><br><br><br><br>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

<style>
  body{
        background: linear-gradient(rgb(15, 138, 175),rgb(81, 124, 81),rgb(115, 165, 36)) fixed;
    }
.card{
    width:360px;
    background: rgb(14, 13, 13);
    display:block;
    margin:auto;
    border-top-left-radius:14px;
    border-bottom-right-radius:14px;
    box-shadow: rgba(114, 61, 61, 0.4) 5px 5px,
    rgba(184, 42, 42, 0.3) 10px 10px, 
    rgba(221, 24, 24, 0.2) 15px 15px,
     rgba(236, 11, 11, 0.1) 20px 20px, 
     rgba(253, 2, 2, 0.05) 25px 25px;
     margin-bottom:50px;
}
.card-title{
    color:white;
}
.form-group{
    color:white;
}
</style>

<div class="card text-center">

<div class="card-body">
  <h2 class="card-title">Donate to uplift society</h2>
  <form action="/pay.php" method="POST">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name">
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" class="form-control my-2" id="phone" name="phone">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" class="form-control my-2" id="email" name="email">
        </div>
        <div class="form-group">
            <label for="amt">Enter Amount</label>
            <input type="text" class="form-control my-2" id="amt" name="amt" placeholder="Enetr amount">
        </div>
        <a href="#" type="submit" class="btn btn-outline-primary" id="btn" name="btn" onclick="pay_now()">Submit</a>
     </form>
</div>

</div>
<script>
function pay_now(){
        var name=jQuery('#name').val();
        var email=jQuery('#email').val();
        var phone=jQuery('#phone').val();
        var amt=jQuery('#amt').val();
        
         jQuery.ajax({
               type:'POST',
               url:'/payment_process.php',
               data:"amt="+amt+"&name="+name+"&email="+email+"&phone="+phone,
               success:function(result){
                   var options = {
                        "key": "rzp_test_jF4WGDFlm3sWrp", 
                        "amount": amt*100, 
                        "currency": "INR",
                        "name": "Ansrcoach Social Upliftment",
                        "description": "One penny is equal to one life",
                        "image": "/logo.png",
                        "handler": function (response){
                           jQuery.ajax({
                               type:'POST',
                               url:'/payment_process.php',
                               data:"payment_id="+response.razorpay_payment_id,
                               success:function(result){
                                   window.location.href="/pay.php";
                               }
                           });
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.open();
               }
           });
        
        
    }
</script>
