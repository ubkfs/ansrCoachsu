<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ansrCoach Society Upliftment</title>
</head>
<style>
    *{
        box-sizing: border-box;
    }
    html{
        min-height:100%;
    }
    body{
        background: linear-gradient(rgb(15, 138, 175),rgb(81, 124, 81),rgb(115, 165, 36)) fixed;
    }

    .button {
        position: absolute;
        float: right;
        margin-left: 1450px;
        background-color: burlywood;
        margin-top: 10px;
        height: 30px;
        padding: 5px;
    }

    .button:hover {
        background-color: cadetblue;
    }

    .head {
        margin: auto;
        text-align: center;

    }

    .main{
       margin: 10px;
       margin-right:19px;
    }
    .main .section{
        width: 100%;
        padding:15px;
        background-color: aqua;
        overflow: auto;
        border-radius: 20px;
    }
    .para {
        background-color: chocolate;
    }
    section{
        margin:10px;
        overflow: auto;
    }
    h3 {
        color: red;
    }
    .card{
        padding:10px;
        color:yellow;
    }
    .card-body{
        background-color:#1E3E93;
    }
    .col-sm-6{
        padding:10px;
    }
    .foot{
        margin-bottom: 0em;
    }
    footer{
        padding-left: 40px;
         padding-right: 40px;
    }
    footer p{
        border-radius: 15px;
    }
    @media screen and (max-width:719px){
        .main{
          margin: 0px;
        }
      .main .section{
        flex-direction: column;
        width: fit-content;
      }
      footer{
          flex-direction: column;
          text-align: center;
          padding-left: 10px;
         padding-right: 10px;
      } 
      footer p{
          border-radius: 15px;
      }
    }
    @media screen and (max-width:600px) {
        .main{
            width: 100%;
        }
        h1{
            font-size: 48px;
        }
    }
    @media screen and (min-width:720px){
        .main{
            width: 95%;
        }
    }
    @media screen and (min-width:1200px){
        .main{
            width:85%;
        }
    }
</style>

<body>

    <?php require "../public_html/in/nav.php" ?>
    <br><br><br><br><br>
    <div id="carouselExampleCaptions" class="carousel slide carousel-fade" data-bs-ride="carousel">

        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="/2.jpg" id="iimg" class="d-block w-100" width="100" height="300" alt="...">
                <div class="carousel-caption d-none d-md-block">

                </div>
            </div>
        </div>
        <br>
        <br>
        <div class="main">
        <section class="section">
            <h3>About Us</h3>
            <p> Established by a group of eminent community leaders in 2010, AnsrCoach Society Upliftment has become
                    one of India’s leading non-governmental organizations dedicated to carrying out humanitarian and
                    development programs to ﬁght poverty and people’s sufferings by working in partnership with
                    vulnerable and at risk communities regardless of faith, caste, gender or political beliefs. Human
                    Welfare Foundation is striving for a fairer world. Our mission is to help the poor and those in need
                    to live sustainable, self-reliant lives within safe and caring communities. Our work is guided and
                    shaped by the core values of accountability, humanitarianism, neutrality and impartiality,
                    inclusiveness, integrity and co-operation.

                    The ASU acts as an umbrella body with several distinguished and experienced community leaders on its
                    board of trustees. It has over 200 local partners spread over 20 states, implementing 4774 projects.
                    The number of beneﬁciaries so far is well above 9 million.

                    ASU, along with its partners, is primarily focusing on following fronts:

                    Education Healthcare, Micro Finance & Poverty Alleviation, Disaster Management, Civil Rights
                    Protection, Drinking Water, Orphan Care, Women Empowerment and Community Development</p>
        </section>
        <hr>
        <section class="section">
            <h3>Why should you donate us</h3>
            <p>We are working through a very tough situation . There are 70% people in the world are daily leaving 
                their stomach vacant for only not having minimal requirements.We have been organising various kind of 
                food distribution and campaigning and taking dynamic way to improve the situation.
                As all of we know that feeding other will not improve poority , it will increase,thats why we took 
                a campaign to establish those neeedy people to make other established by them .Thats why we require
                lots of help from very kind persons like you .</p>
        </section>
        <hr>
        <section class="section">
            <h3>Our Work</h3>
            <p>We have been working since 2010 and lots of positive feedback and resoponses are motivating us to do 
                more help. Some works are shown in below..</p>
        </section>
    </div>
     <br>
        <div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h3 class="card-title">Visitor's Comment</h3>
        <p class="card-text"><i>This is very good Organisation have i ever seen.The world requires this typeof organisation more.
            Such a wonderful work they are doing man!</i>
        </p>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h3 class="card-title">Visitor's Comment</h3>
        <p class="card-text"><i>I will recommend u all to donate.I personally felt that they are one of best non governmental
            organisation in India.</i>
        </p>
      </div>
    </div>
  </div>
</div>
<br><br>
        <footer class="bg-success">
            <h3 class="mb-2 ms-3 text-light d-flex justify-content-center">Contact</h3>
            <ul class="d-flex d-inline-block justify-content-center" style="list-style:none;">
                <li style="padding: 4px 4px;">
                    <a href="https://www.facebook.com/102261091682758/" title="Facebook" target="_blank" xtm-t="E"
                        xtm-n="Social-footer::">
                        <img src="/fb.png" style="width: 30px;height: 30px;" alt=""></a>
                </li>
                <li>
                    <a href="https://wa.me/c/" title="Whatsapp" target="_blank" xtm-t="E"
                        xtm-n="Social-footer::">
                        <img src="/whatsapp.png" class="my-1" style="width: 30px;height: 30px;"
                            alt=""></a>
                </li>
            </ul>
            <p class="d-flex justify-content-center bg-light mb-2"><a href="/tnc.html">Terms and Condition</a>
            </p>
            <p class="d-flex justify-content-center bg-light my-2"><a href="/privacy.html">Privacy Policy</a>
            </p>
            <p class="d-flex justify-content-center bg-light my-2"><a href="/refund.html">Refund Policy</a></p>
            <p class="d-flex justify-content-center text-danger bg-dark my-2 foot">Copyright @AnsrCoachsocietyupliftment2021 </p>
        </footer>
    
</body>

</html>

<!-- ansrCoachsu
V$vZDERb8$U!@^!FnSnT -->